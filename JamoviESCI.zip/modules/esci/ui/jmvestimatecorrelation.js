(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){
    module.exports = {

        // event handlers and functions are defined here

        // this is an example of an event handler
        view_loaded: function(ui, event) {
            // do something
            this.setPanels(ui, event);
        },

        // this is another example of an event handler
        switchr_changed: function(ui, event) {
            this.setPanels(ui, event);
        },

        // this is an example of an auxiliary function
        setPanels: function(ui, event) {
            // check if summary or raw data option selected, and then set panel and enabled states appropriately
            if (ui.switchs.value()){
              // summary data option - expand that panel and collapse the raw panel
              // also set all controls in summary panel to be enabled
              // would be nice to be able to disable the controls in the raw data panel and/or expand option for that panel
              ui.spanel.expand();
              ui.rpanel.collapse();
              ui.scatterpanel.collapse();
            } else {
              // raw data selected, so expand that panel, collapse summary data panel and disable its controls
              // would be nice to disable collapse/expand options on the panels, but doesn't seem possible at the moment
              ui.spanel.collapse();
              ui.rpanel.expand();
            }
            
            ui.r.setEnabled(ui.switchs.value());
            ui.n.setEnabled(ui.switchs.value());

        }


    };
},{}],2:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"switch","type":"List","default":"fromraw","options":[{"name":"fromraw","title":"Analyze raw data"},{"name":"fromsummary","title":"Enter summary data"}]},{"name":"data","type":"Data"},{"name":"dv","title":"Variable to predict (Y)","type":"Variable","permitted":["numeric"]},{"name":"iv","title":"Predictor variable (X)","type":"Variable","permitted":["numeric"]},{"name":"show.line","title":"Show regression line","type":"Bool","default":false},{"name":"show.meanCI","title":"Show CI on regression line","type":"Bool","default":false},{"name":"show.PI","title":"Prediction intervals","type":"Bool","default":false},{"name":"predictx","type":"String","title":"Give X value to make a prediction (Y')","default":"none"},{"name":"r","title":"r value","type":"Number","min":0,"max":1},{"name":"n","title":"Sample size","type":"Number"},{"name":"conf.level","type":"Number","title":"Confidence level","min":50,"max":99.9999,"default":95},{"name":"ylab","title":"y-axis label","type":"String"},{"name":"xlab","title":"x-axis label","type":"String"},{"name":"size","title":"Point size","type":"Number","default":3},{"name":"ymin","title":"y-axis minimum","type":"String","default":"auto"},{"name":"ymax","title":"y-axis maxmimum","type":"String","default":"auto"},{"name":"xmin","title":"x-axis minimum","type":"String","default":"auto"},{"name":"xmax","title":"x-axis maxmimum","type":"String","default":"auto"}];

const view = function() {
    
    this.handlers = require('./jmvestimatecorrelation')

    View.extend({
        jus: "3.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Estimate Correlation",
    jus: "3.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			style: "inline",
			controls: [
				{
					type: DefaultControls.RadioButton,
					typeName: 'RadioButton',
					name: "switchr",
					optionName: "switch",
					optionPart: "fromraw"
				},
				{
					type: DefaultControls.RadioButton,
					typeName: 'RadioButton',
					name: "switchs",
					optionName: "switch",
					optionPart: "fromsummary"
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Work With Raw Data",
			name: "rpanel",
			collapsed: false,
			controls: [
				{
					type: DefaultControls.VariableSupplier,
					typeName: 'VariableSupplier',
					persistentItems: false,
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							label: "Variable to predict (Y)",
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "dv",
									maxItemCount: 1,
									isTarget: true
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							label: "Predictor variable (X)",
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "iv",
									maxItemCount: 1,
									isTarget: true
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "show.line"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "show.meanCI"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "show.PI"
						},
						{
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							name: "predictx",
							format: FormatDef.string
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Work With Summary Data",
			name: "spanel",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "r",
					format: FormatDef.number
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "n",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.Label,
			typeName: 'Label',
			label: "Other analysis options",
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "conf.level",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Scatter Plot Options",
			name: "scatterpanel",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ylab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "xlab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "size",
					format: FormatDef.number
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ymin",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ymax",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "xmin",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "xmax",
					format: FormatDef.string
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{"./jmvestimatecorrelation":1}]},{},[2])(2)
});
(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){
    module.exports = {

        // event handlers and functions are defined here

        // this is an example of an event handler
        view_loaded: function(ui, event) {
            // do something
            this.setPanels(ui, event);
        },

        // this is another example of an event handler
        switchr_changed: function(ui, event) {
            this.setPanels(ui, event);
        },

        // this is an example of an auxiliary function
        setPanels: function(ui, event) {
            // check if summary or raw data option selected, and then set panel and enabled states appropriately
            if (ui.switchs.value()){
              // summary data option - expand that panel and collapse the raw panel
              // also set all controls in summary panel to be enabled
              // would be nice to be able to disable the controls in the raw data panel and/or expand option for that panel
              ui.spanel.expand();
              ui.rpanel.collapse();
              ui.m1.setEnabled(true);
              ui.m2.setEnabled(true);
              ui.s1.setEnabled(true);
              ui.s2.setEnabled(true);
              ui.n1.setEnabled(true);
              ui.n2.setEnabled(true);
              ui.g1lab.setValue("Reference Group");
              ui.g2lab.setValue("Comparison Group");
            } else {
              // raw data selected, so expand that panel, collapse summary data panel and disable its controls
              // would be nice to disable collapse/expand options on the panels, but doesn't seem possible at the moment
              ui.spanel.collapse();
              ui.rpanel.expand();
              ui.m1.setEnabled(false);
              ui.m2.setEnabled(false);
              ui.s1.setEnabled(false);
              ui.s2.setEnabled(false);
              ui.n1.setEnabled(false);
              ui.n2.setEnabled(false);
              ui.g1lab.setValue("auto");
              ui.g2lab.setValue("auto");
            }
        }


    };
},{}],2:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"switch","type":"List","default":"fromraw","options":[{"name":"fromraw","title":"Analyze raw data"},{"name":"fromsummary","title":"Enter summary data"}]},{"name":"data","type":"Data"},{"name":"y","title":"Dependent variable","type":"Variable"},{"name":"x","title":"Grouping variable","type":"Variable"},{"name":"reference.group","title":"Switch comparison order","type":"Bool","default":false},{"name":"m1","title":"m1","type":"Number"},{"name":"m2","title":"m2","type":"Number"},{"name":"s1","title":"s1","type":"Number"},{"name":"s2","title":"s2","type":"Number"},{"name":"n1","title":"n1","type":"Number"},{"name":"n2","title":"n2","type":"Number"},{"name":"conf.level","type":"Number","title":"Confidence level","min":50,"max":99.9999,"default":95},{"name":"var.equal","title":"Assume equal variances","type":"Bool","default":true},{"name":"ymin","title":"y-axis minimum","type":"String","default":"auto"},{"name":"ymax","title":"y-axis maxmimum","type":"String","default":"auto"},{"name":"ylab","title":"y-axis label","type":"String"},{"name":"xlab","title":"x-axis label","type":"String"},{"name":"g1lab","title":"Group 1 label","type":"String","default":"auto"},{"name":"g2lab","title":"Group 2 label","type":"String","default":"auto"},{"name":"g1color","title":"Group 1 color","type":"String","default":"white"},{"name":"g2color","title":"Group 2 color","type":"String","default":"gray75"},{"name":"bsize","type":"Number","title":"Point size","min":0.5,"max":10,"default":2},{"name":"bcex","type":"Number","title":"Swarm clustering","min":0.5,"max":10,"default":1},{"name":"ropeBottom","title":"Region of Practical Equivalence (ROPE) bottom","type":"String","default":"none"},{"name":"ropeTop","title":"Region of Practical Equivalence (ROPE) top","type":"String","default":"none"}];

const view = function() {
    
    this.handlers = require('./jmvestimateindmeandifference')

    View.extend({
        jus: "3.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Estimate Independent Mean Difference",
    jus: "3.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			style: "inline",
			controls: [
				{
					type: DefaultControls.RadioButton,
					typeName: 'RadioButton',
					name: "switchr",
					optionName: "switch",
					optionPart: "fromraw"
				},
				{
					type: DefaultControls.RadioButton,
					typeName: 'RadioButton',
					name: "switchs",
					optionName: "switch",
					optionPart: "fromsummary"
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Work With Raw Data",
			name: "rpanel",
			collapsed: false,
			controls: [
				{
					type: DefaultControls.VariableSupplier,
					typeName: 'VariableSupplier',
					persistentItems: false,
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							label: "Dependent variable",
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "y",
									maxItemCount: 1,
									isTarget: true
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							label: "Grouping variable",
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "x",
									maxItemCount: 1,
									isTarget: true
								}
							]
						}
					]
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "reference.group"
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Work With Summary Data",
			name: "spanel",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Group 1 data (reference group)",
					controls: [
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							margin: "large",
							style: "inline",
							controls: [
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "m1",
									format: FormatDef.number
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "s1",
									format: FormatDef.number
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "n1",
									format: FormatDef.number
								}
							]
						}
					]
				},
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Group 2 data (comparison group)",
					controls: [
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							margin: "large",
							style: "inline",
							controls: [
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "m2",
									format: FormatDef.number
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "s2",
									format: FormatDef.number
								},
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "n2",
									format: FormatDef.number
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.Label,
			typeName: 'Label',
			label: "Analysis options",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "conf.level",
					format: FormatDef.number
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "var.equal"
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Region of Practical Equivalence (ROPE) Options",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ropeBottom",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ropeTop",
					format: FormatDef.string
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Graph Options",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ymin",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ymax",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ylab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "xlab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "g1lab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "g2lab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "g1color",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "g2color",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "bsize",
					format: FormatDef.number
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "bcex",
					format: FormatDef.number
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{"./jmvestimateindmeandifference":1}]},{},[2])(2)
});
(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data"},{"name":"measure1","title":"Measure","type":"Variable"},{"name":"plottype","type":"List","default":"dotplot","options":[{"name":"dotplot","title":"Dot plot"},{"name":"histogram","title":"Histogram"}]},{"name":"marker","type":"String","title":"Percentile for marker","default":"none"},{"name":"bins","type":"String","title":"Number of bins","default":"12"},{"name":"show.mean","title":"Mean marker","type":"Bool","default":false},{"name":"show.median","title":"Median marker","type":"Bool","default":false},{"name":"show.zlines","title":"z-line markers","type":"Bool","default":false},{"name":"show.s","title":"Standard deviation marker","type":"Bool","default":false},{"name":"ylab","title":"y-axis label","type":"String"},{"name":"xlab","title":"x-axis label","type":"String"},{"name":"size","title":"Point size","type":"String","default":"1"},{"name":"ymin","title":"y-axis minimum","type":"String","default":"auto"},{"name":"ymax","title":"y-axis maximum","type":"String","default":"auto"},{"name":"xmin","title":"x-axis minimum","type":"String","default":"auto"},{"name":"xmax","title":"x-axis maximum","type":"String","default":"auto"},{"name":"color.regular","title":"Color for bars/dots","type":"String","default":"gray"},{"name":"color.highlighted","title":"Color for highlighted bars/dots","type":"String","default":"red"}];

const view = function() {
    
    this.handlers = { }

    View.extend({
        jus: "3.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Descriptives",
    jus: "3.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Measure",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "measure1",
							maxItemCount: 1,
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Distribution-Graph Options",
			collapsed: false,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					style: "inline",
					controls: [
						{
							type: DefaultControls.RadioButton,
							typeName: 'RadioButton',
							optionName: "plottype",
							optionPart: "dotplot"
						},
						{
							type: DefaultControls.RadioButton,
							typeName: 'RadioButton',
							optionName: "plottype",
							optionPart: "histogram"
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							name: "marker",
							format: FormatDef.string
						},
						{
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							name: "bins",
							format: FormatDef.string
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "show.mean"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "show.median"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "show.zlines"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "show.s"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Other Graph Options",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ylab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "xlab",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ymin",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "ymax",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "xmin",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "xmax",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "color.regular",
					format: FormatDef.string
				},
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "color.highlighted",
					format: FormatDef.string
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					name: "size",
					format: FormatDef.string
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"x","title":"X-Axis","type":"Variable","suggested":["continuous"],"permitted":["numeric"],"description":{"R":"a string naming the variable from `data` that contains the  x coordinates of the points in the plot, variable must be numeric  \n"}},{"name":"y","title":"Y-Axis","type":"Variable","suggested":["continuous"],"permitted":["numeric"],"description":{"R":"a string naming the variable from `data` that contains the  y coordinates of the points in the plot, variable must be numeric  \n"}},{"name":"group","title":"Group","type":"Variable","suggested":["nominal"],"permitted":["factor"],"default":null,"description":{"R":"a string naming the variable from `data` that represents the  grouping variable\n"}},{"name":"marg","title":"Marginals","type":"List","options":[{"title":"None","name":"none"},{"title":"Densities","name":"dens"},{"title":"Boxplots","name":"box"}],"default":"none","description":{"R":"`none` (default), `dens`, or `box`, provide respectively no plots, density plots, or box plots on the axes\n"}},{"name":"line","title":"Regression Line","type":"List","options":[{"title":"None","name":"none"},{"title":"Linear","name":"linear"},{"title":"Smooth","name":"smooth"}],"default":"none","description":{"R":"`none` (default), `linear`, or `smooth`, provide respectively no regression line,  a linear regression line, or a smoothed regression line\n"}},{"name":"se","title":"Standard error","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), show the standard error for the regression line\n"}}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Scatterplot",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "X-Axis",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "x",
							maxItemCount: 1,
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Y-Axis",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "y",
							maxItemCount: 1,
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Group",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "group",
							maxItemCount: 1,
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					cell: {"column":0,"row":0},
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Regression Line",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "line_none",
									optionName: "line",
									optionPart: "none"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "line_linear",
									optionName: "line",
									optionPart: "linear"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "line_smooth",
									optionName: "line",
									optionPart: "smooth"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "se",
									enable: "(!line_none)"
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					cell: {"column":1,"row":0},
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Marginals",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "marg_none",
									optionName: "marg",
									optionPart: "none"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "marg_dens",
									optionName: "marg",
									optionPart: "dens"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "marg_box",
									optionName: "marg",
									optionPart: "box"
								}
							]
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
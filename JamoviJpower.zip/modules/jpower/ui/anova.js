(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"estype","title":"Effect size type","type":"List","options":["f","omega"],"default":"f"},{"name":"es","title":"Minimally-interesting effect size","type":"Number","min":0,"default":0.3},{"name":"power","title":"Minimum desired power","type":"Number","min":0,"max":1,"default":0.8},{"name":"n","title":"N per group","type":"Integer","min":2,"default":20},{"name":"k","title":"Number of groups","type":"Integer","min":2,"default":3},{"name":"alpha","title":"&alpha; (type I error rate)","type":"Number","min":0,"default":0.05},{"name":"powerDist","title":"Power demonstration","type":"Bool","default":true},{"name":"powerCurveES","title":"Power curve by effect size","type":"Bool","default":false},{"name":"powerCurveN","title":"Power curve by N","type":"Bool","default":false}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "ANOVA",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					name: "estype",
					type: DefaultControls.ComboBox,
					typeName: 'ComboBox',
					label: "Effect size type",
					options: [{"title":"f","name":"f"},{"title":"ω²","name":"omega"}]
				},
				{
					name: "es",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "Minimally-interesting effect size",
					format: FormatDef.number
				},
				{
					name: "power",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "Minimum desired power",
					format: FormatDef.number
				},
				{
					name: "n",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "N per group",
					format: FormatDef.number
				},
				{
					name: "k",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "Number of groups",
					format: FormatDef.number
				},
				{
					name: "alpha",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "&alpha; (type I error rate)",
					format: FormatDef.number
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Plots",
					controls: [
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "powerDist"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "powerCurveES"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "powerCurveN"
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
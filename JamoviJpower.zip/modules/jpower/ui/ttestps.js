(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"calc","title":"Calculate","type":"List","options":[{"name":"n","title":"N"},{"name":"power","title":"Power"},{"name":"es","title":"Effect size"}],"default":"n"},{"name":"es","title":"Minimally-interesting effect size (&delta;)","type":"Number","min":0.01,"default":0.5},{"name":"power","title":"Minimum desired power","type":"Number","min":0,"max":1,"default":0.9},{"name":"n","title":"N","type":"Integer","min":2,"default":20},{"name":"alt","title":"Tails","type":"List","options":["two.sided","less","greater"],"default":"two.sided"},{"name":"alpha","title":"&alpha; (type I error rate)","type":"Number","min":0,"default":0.05},{"name":"powerContour","title":"Power contour plot","type":"Bool","default":true},{"name":"powerDist","title":"Power demonstration","type":"Bool","default":false},{"name":"powerCurveES","title":"Power curve by effect size","type":"Bool","default":true},{"name":"powerCurveN","title":"Power curve by N","type":"Bool","default":false},{"name":"text","title":"Explanatory text","type":"Bool","default":true}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Paired Samples T-Test",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.ComboBox,
					typeName: 'ComboBox',
					name: "calc"
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					name: "es",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "Minimally-interesting effect size (&delta;)",
					format: FormatDef.number,
					enable: "(!calc:es)"
				},
				{
					name: "power",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "Minimum desired power",
					format: FormatDef.number,
					enable: "(!calc:power)"
				},
				{
					name: "n",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "N",
					format: FormatDef.number,
					enable: "(!calc:n)"
				},
				{
					name: "alpha",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "&alpha; (type I error rate)",
					format: FormatDef.number,
					enable: "(!calc:alpha)",
					suggestedValues: [{"value":0.1},{"value":0.05},{"value":0.01},{"value":0.005},{"value":0.001}]
				},
				{
					name: "alt",
					type: DefaultControls.ComboBox,
					typeName: 'ComboBox',
					label: "Tails",
					options: [{"title":"two-tailed","name":"two.sided"},{"title":"one-tailed (consistent)","name":"greater"}]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					stretchFactor: 1,
					cell: {"column":0,"row":0},
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Plots",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "powerContour"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "powerCurveES",
									enable: "(!calc:n)"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "powerCurveN",
									enable: "(!calc:es)"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "powerDist"
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Additional Options",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "text"
								}
							]
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
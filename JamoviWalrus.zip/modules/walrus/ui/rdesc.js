(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"vars","title":"Variables","type":"Variables","suggested":["continuous"],"permitted":["numeric"],"description":{"R":"a vector of strings naming the variables in `data` of interest"}},{"name":"splitBy","title":"Split by","type":"Variable","default":null,"suggested":["nominal"],"permitted":["factor"],"description":{"R":"a string naming the variable in `data` to split the data by"}},{"name":"mean","title":"Vanilla mean","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, provide a 'normal' arithmetic mean\n"}},{"name":"trim","title":"Trimmed mean","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, provide a trimmed mean\n"}},{"name":"tr","title":"Trim proportion","type":"Number","default":0.2,"min":0,"max":0.5,"description":{"R":"a number between 0 and 0.5 (default: 0.2); the proportion of measurements to trim from each end when producing trimmed means\n"}},{"name":"win","title":"Winsorized mean","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide a 'Winsorized' mean\n"}},{"name":"wl","title":"Winsorizing level","type":"Number","default":0.2,"min":0,"max":0.5,"description":{"R":"a number between 0 and 0.5 (default: 0.2); the level of 'winsorizing' when producing winsorized means\n"}},{"name":"mest","title":"M-estimator","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide an 'M-estimated' value\n"}},{"name":"bend","title":"Bending constant","type":"Number","default":1.28,"description":{"R":"a number (default: 1.28), the bending constant to use when using M-estimators\n"}},{"name":"med","title":"Median","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide medians\n"}}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Robust Descriptives",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Variables",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "vars",
							height: "normal",
							showColumnHeaders: false,
							fullRowSelect: true,
							columns: [
								{
									name: "column1",
									label: "",
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel'
									}									
								}
							],
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Split by",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "splitBy",
							maxItemCount: 1,
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Estimates",
							controls: [
								{
									name: "mean",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									label: "Vanilla mean"
								},
								{
									name: "trim",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									label: "Trimmed mean",
									controls: [
										{
											name: "tr",
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											label: "Trim proportion",
											format: FormatDef.number
										}
									]
								},
								{
									name: "med",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									label: "Median"
								},
								{
									type: DefaultControls.LayoutBox,
									typeName: 'LayoutBox',
									controls: [
										{
											name: "win",
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											label: "Winsorized mean",
											controls: [
												{
													name: "wl",
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													label: "Winsorizing level",
													format: FormatDef.number
												}
											]
										},
										{
											name: "mest",
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											label: "M-estimator",
											controls: [
												{
													name: "bend",
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													label: "Bending constant",
													format: FormatDef.number
												}
											]
										}
									]
								}
							]
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
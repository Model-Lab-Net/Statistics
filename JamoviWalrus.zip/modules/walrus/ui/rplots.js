(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"vars","title":"Variables","type":"Variables","suggested":["continuous"],"permitted":["numeric"],"description":{"R":"a vector of strings naming the variables in `data` of interest"}},{"name":"splitBy","title":"Split by","type":"Variable","default":null,"suggested":["nominal"],"permitted":["factor"],"description":{"R":"a string naming the variable in `data` to split the data by"}},{"name":"violin","title":"Violin","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, provide violin plots\n"}},{"name":"boxplot","title":"Boxplot","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide box plots\n"}},{"name":"dot","title":"Data","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, plot each measurement as a dot\n"}},{"name":"dotType","title":"","type":"List","options":[{"name":"jitter","title":"Jittered"},{"name":"stack","title":"Stacked"}],"default":"stack","description":{"R":"`'jitter'` or `'stack'` (default); whether data dots are jittered or stacked\n"}}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Box & Violin plots",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Variables",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "vars",
							height: "normal",
							showColumnHeaders: false,
							fullRowSelect: true,
							columns: [
								{
									name: "column1",
									label: "",
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel'
									}									
								}
							],
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Split by",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "splitBy",
							maxItemCount: 1,
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.Label,
			typeName: 'Label',
			label: "Plot Elements",
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "violin"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "boxplot"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "dot",
					style: "list-inline",
					controls: [
						{
							type: DefaultControls.ComboBox,
							typeName: 'ComboBox',
							name: "dotType",
							enable: "(dot)"
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
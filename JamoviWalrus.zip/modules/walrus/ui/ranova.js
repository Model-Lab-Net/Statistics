(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"dep","title":"Dependent","type":"Variable","suggested":["continuous"],"permitted":["numeric"],"description":{"R":"a string naming the dependent variable from `data`; the variable must be numeric\n"}},{"name":"factors","title":"Factors","type":"Variables","suggested":["nominal","ordinal"],"permitted":["factor"],"default":null,"description":{"R":"a vector of strings naming the fixed factors from `data`"}},{"name":"method","title":"Method","type":"List","options":["median","trim","boot"],"default":"trim","description":{"R":"`'median'`, `'trim'` (default) or `'boot'`; the method to use, median, trimmed means, or bootstrapped\n"}},{"name":"ph","title":"Post hoc tests","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide post hoc tests\n"}},{"name":"tr","title":"Trim proportion","type":"Number","min":0,"max":0.5,"default":0.2,"description":{"R":"a number between 0 and 0.5, (default: 0.2), the proportion of measurements to trim from each end, when using the trim and bootstrap methods\n"}},{"name":"est","title":"Estimator","type":"List","options":[{"title":"One-step","name":"onestep"},{"name":"mom","title":"Modified one-step"},{"name":"median","title":"Median"}],"default":"mom","description":{"R":"`'onestep'`, `'mom'` (default) or `'median'`, the M-estimator to use; One-step, Modified one-step or Median respectively\n"}},{"name":"nboot","title":"Samples","type":"Integer","min":0,"default":599,"description":{"R":"a number (default: 599) specifying the number of bootstrap samples to use when using the bootstrap method\n"}},{"name":"dist","title":"Distances","type":"List","options":[{"name":"maha","title":"Mahalanobis"},{"name":"proj","title":"Projection"}],"default":"proj","description":{"R":"`'maha'` or `'proj'` (default), whether to use Mahalanobis or Projection distances respectively\n"}}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Robust ANOVA",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Dependent",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "dep",
							maxItemCount: 1,
							showColumnHeaders: false,
							fullRowSelect: true,
							columns: [
								{
									name: "column1",
									label: "",
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel'
									}									
								}
							],
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Factors",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "factors",
							showColumnHeaders: false,
							fullRowSelect: true,
							columns: [
								{
									name: "column1",
									label: "",
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel'
									}									
								}
							],
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.Label,
			typeName: 'Label',
			label: "Method",
			margin: "large",
			controls: [
				{
					type: DefaultControls.RadioButton,
					typeName: 'RadioButton',
					name: "method_median",
					optionName: "method",
					optionPart: "median",
					label: "Median"
				},
				{
					type: DefaultControls.RadioButton,
					typeName: 'RadioButton',
					name: "method_trim",
					optionName: "method",
					optionPart: "trim",
					label: "Trim",
					controls: [
						{
							name: "tr",
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							label: "Trim proportion",
							format: FormatDef.number,
							enable: "(method:trim)"
						}
					]
				},
				{
					type: DefaultControls.RadioButton,
					typeName: 'RadioButton',
					name: "method_boot",
					optionName: "method",
					optionPart: "boot",
					label: "Bootstrap",
					controls: [
						{
							name: "est",
							type: DefaultControls.ComboBox,
							typeName: 'ComboBox',
							label: "Estimator",
							enable: "(method:boot)"
						},
						{
							name: "nboot",
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							label: "Samples",
							format: FormatDef.number,
							enable: "(method:boot)"
						},
						{
							name: "dist",
							type: DefaultControls.ComboBox,
							typeName: 'ComboBox',
							label: "Distances",
							enable: "(method:boot)"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.Label,
			typeName: 'Label',
			label: "Additional Statistics",
			cell: {"column":1,"row":1},
			margin: "large",
			controls: [
				{
					name: "ph",
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					label: "Post hoc tests"
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
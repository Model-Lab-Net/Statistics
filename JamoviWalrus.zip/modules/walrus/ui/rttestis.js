(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"deps","title":"Dependent Variables","type":"Variables","description":{"R":"a vector of strings naming the dependent variables in `data`"},"suggested":["continuous"],"permitted":["numeric"]},{"name":"group","title":"Grouping Variable","type":"Variable","description":{"R":"a string naming the grouping variable in `data`; must have 2 levels"},"suggested":["nominal"],"permitted":["factor"]},{"name":"yuen","title":"Yuen's","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, use the Yuen's trim method\n"}},{"name":"tr","title":"Trim proportion","type":"Number","default":0.2,"min":0,"max":0.5,"description":{"R":"a number between 0 and 0.5, (default: 0.2), the proportion of measurements to trim from each end, when using the trim and bootstrap methods\n"}},{"name":"mest","title":"M-estimator","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), use an M-estimator\n"}},{"name":"method","title":"Method","type":"List","options":[{"name":"onestep","title":"One-step"},{"name":"mom","title":"Modified one-step"},{"name":"median","title":"Median"},{"name":"mean","title":"Mean"}],"default":"mom","description":{"R":"`'onestep'`, `'mom'` (default) or `'median'`, the M-estimator to use; One-step, Modified one-step or Median respectively\n"}},{"name":"yuenbt","title":"Bootstrap","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), use the Yuen's bootstrap method\n"}},{"name":"nboot","title":"Samples","type":"Integer","min":0,"default":599,"description":{"R":"a number (default: 599) specifying the number of bootstrap samples to use when using the bootstrap method\n"}},{"name":"md","title":"Mean difference","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide the mean difference\n"}},{"name":"ci","title":"Confidence interval","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide a 95% confidence interval on the mean difference\n"}},{"name":"es","title":"Effect-size","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide the effect-size\n"}},{"name":"esci","title":"Confidence interval","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide a 95% confidence interval on the effect-size\n"}}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Robust Independent Samples T-Test",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Dependent Variables",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "deps",
							showColumnHeaders: false,
							fullRowSelect: true,
							columns: [
								{
									name: "column1",
									label: "",
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel'
									}									
								}
							],
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Grouping Variable",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "group",
							maxItemCount: 1,
							showColumnHeaders: false,
							fullRowSelect: true,
							columns: [
								{
									name: "column1",
									label: "",
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel'
									}									
								}
							],
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.Label,
			typeName: 'Label',
			label: "Yuen's",
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "yuen",
					label: "Yuen's",
					controls: [
						{
							name: "tr",
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							label: "Trim proportion",
							format: FormatDef.number
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "yuenbt",
							label: "Bootstrap",
							controls: [
								{
									type: DefaultControls.TextBox,
									typeName: 'TextBox',
									name: "nboot",
									label: "Samples",
									format: FormatDef.number
								}
							]
						},
						{
							name: "md",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							label: "Mean difference"
						},
						{
							name: "ci",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							label: "Confidence interval"
						},
						{
							name: "es",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							label: "Effect-size",
							controls: [
								{
									name: "esci",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									label: "Confidence interval"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.Label,
			typeName: 'Label',
			label: "M-estimator",
			cell: {"row":1,"column":1},
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "mest",
					label: "M-estimator",
					controls: [
						{
							name: "method",
							type: DefaultControls.ComboBox,
							typeName: 'ComboBox',
							label: "Method"
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
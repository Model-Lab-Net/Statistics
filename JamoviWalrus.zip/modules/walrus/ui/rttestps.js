(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"pairs","title":"Paired Variables","type":"Pairs","suggested":["continuous"],"permitted":["numeric"],"description":{"R":"a list of lists specifying the pairs of measurement in `data`"}},{"name":"tr","title":"Trim proportion (γ)","type":"Number","min":0,"max":0.5,"default":0.2,"description":{"R":"a number between 0 and 0.5, (default: 0.2), the proportion of measurements to trim from each end, when using the trim and bootstrap methods\n"}},{"name":"md","title":"Mean difference","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide means and standard errors\n"}},{"name":"es","title":"Effect size","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide effect sizes\n"}},{"name":"ci","title":"Confidence interval","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide confidence intervals\n"}}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Paired Samples T-Test",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			suggested: ["continuous"],
			permitted: ["numeric"],
			persistentItems: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Paired Variables",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "pairs",
							showColumnHeaders: false,
							fullRowSelect: true,
							itemDropBehaviour: "overwrite",
							columns: [
								{
									name: "i1",
									label: null,
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel',
										format: FormatDef.variable
									}									
								},
								{
									name: "i2",
									label: null,
									stretchFactor: 1,
									template:
									{
										type: DefaultControls.VariableLabel,
										typeName: 'VariableLabel',
										format: FormatDef.variable
									}									
								}
							],
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			controls: [
				{
					name: "tr",
					type: DefaultControls.TextBox,
					typeName: 'TextBox',
					label: "Trim proportion",
					format: FormatDef.number
				},
				{
					name: "md",
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					label: "Mean difference"
				},
				{
					name: "ci",
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					label: "Confidence interval"
				},
				{
					name: "es",
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					label: "Effect size"
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});
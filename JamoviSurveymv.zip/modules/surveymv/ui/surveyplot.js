(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","requiresMissings":false},{"name":"vars","title":"Variables","type":"Variables","required":true},{"name":"group","title":"Grouping Variable","type":"Variable","default":null,"suggested":["nominal","ordinal"],"permitted":["factor"]},{"name":"type","title":"Plot Type","type":"List","options":[{"title":"Grouped bar","name":"grouped"},{"title":"Stacked bar","name":"stacked"}],"default":"grouped","description":{"R":"`grouped` (default), or `stacked`, provide respectively grouped, or stacked bar plots\n"}},{"name":"freq","title":"Frequency Type","type":"List","options":[{"title":"Counts","name":"count"},{"title":"Percentages","name":"perc"}],"default":"count","description":{"R":"`count` (default), or `perc`, provide respectively counts,  or percentages as the frequencies\n"}},{"name":"labels","title":"Frequency Labels","type":"List","options":[{"title":"In plot","name":"inPlot"},{"title":"On x-axis","name":"onAxis"}],"default":"inPlot","description":{"R":"`inPlot` (default), or `onAxis`, show the bar labels respectively in the plot  near the labels, or on the x-axis\n"}},{"name":"desc","title":"Variable description","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, show variable description in the plot\n"}},{"name":"hideNA","title":"Hide missing values","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, hide missing values in the plot\n"}},{"name":"box","title":"Box plot","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, add box plot element to continuous plots\n"}},{"name":"violin","title":"Violin","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, add violin plot element to continuous plots\n"}},{"name":"dot","title":"Data","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, add data dot plot element to continuous plots\n"}}];

const view = function() {
    
    this.handlers = { }

    View.extend({
        jus: "3.0",

        events: [

	]

    }).call(this);
}

view.layout = ui.extend({

    label: "Survey Plots",
    jus: "3.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Variables",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "vars",
							isTarget: true
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					label: "Grouping Variable",
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "group",
							maxItemCount: 1,
							isTarget: true
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CheckBox,
			typeName: 'CheckBox',
			name: "desc"
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Nominal / Ordinal Plots",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							cell: {"column":0,"row":0},
							stretchFactor: 1,
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Plot Type",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "type_grouped",
											optionName: "type",
											optionPart: "grouped"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "type_stacked",
											optionName: "type",
											optionPart: "stacked"
										}
									]
								},
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Frequency Type",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "freq_count",
											optionName: "freq",
											optionPart: "count"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "freq_perc",
											optionName: "freq",
											optionPart: "perc"
										}
									]
								}
							]
						},
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							cell: {"column":1,"row":0},
							stretchFactor: 1,
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Frequency Labels",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "labels_inPlot",
											optionName: "labels",
											optionPart: "inPlot"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "labels_onAxis",
											optionName: "labels",
											optionPart: "onAxis"
										}
									]
								},
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Additional options",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "hideNA"
										}
									]
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Continuous Plots",
			collapsed: true,
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					stretchFactor: 1,
					controls: [
						{
							type: DefaultControls.LayoutBox,
							typeName: 'LayoutBox',
							cell: {"column":0,"row":0},
							stretchFactor: 1,
							controls: [
								{
									type: DefaultControls.Label,
									typeName: 'Label',
									label: "Plot Elements",
									controls: [
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "violin"
										},
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "box"
										},
										{
											type: DefaultControls.CheckBox,
											typeName: 'CheckBox',
											name: "dot"
										}
									]
								}
							]
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{}]},{},[1])(1)
});